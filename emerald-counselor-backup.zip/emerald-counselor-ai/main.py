from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from openai import OpenAI
import os
from dotenv import load_dotenv
import markdown
import re
import time
import secrets
import sqlite3
from datetime import datetime, date

load_dotenv()

app = Flask(__name__, static_folder='static', static_url_path='/static')
app.secret_key = os.getenv('SECRET_KEY', secrets.token_hex(32))

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
ASSISTANT_ID = os.getenv('OPENAI_ASSISTANT_ID')

print(f"✓ Using Assistant: {ASSISTANT_ID}")

# Database path
DB_PATH = '/home/VihaanAgrawal/emerald-counselor-ai/users.db'

# Rate limit settings
MESSAGES_PER_DAY = 10

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, id, username, class_of, thread_id, messages_today=0, last_message_date=None):
        self.id = id
        self.username = username
        self.class_of = class_of
        self.thread_id = thread_id
        self.messages_today = messages_today
        self.last_message_date = last_message_date

@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT id, username, class_of, thread_id, messages_today, last_message_date FROM users WHERE id = ?', (user_id,))
    user_data = cursor.fetchone()
    conn.close()

    if user_data:
        return User(user_data[0], user_data[1], user_data[2], user_data[3], user_data[4] or 0, user_data[5])
    return None

def process_citations(text):
    citation_pattern = r'【\d+:\d+†[^】]+】'
    text = re.sub(citation_pattern, '', text)
    return text

def check_and_update_rate_limit(user_id):
    """Check if user has exceeded rate limit and update count"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Get user's message count and last message date
    cursor.execute('SELECT messages_today, last_message_date FROM users WHERE id = ?', (user_id,))
    result = cursor.fetchone()

    messages_today = result[0] or 0
    last_message_date = result[1]
    today = str(date.today())

    # Reset count if it's a new day
    if last_message_date != today:
        messages_today = 0

    # Check if user has exceeded limit
    if messages_today >= MESSAGES_PER_DAY:
        conn.close()
        return False, messages_today

    # Increment message count
    messages_today += 1
    cursor.execute('UPDATE users SET messages_today = ?, last_message_date = ? WHERE id = ?',
                   (messages_today, today, user_id))
    conn.commit()
    conn.close()

    return True, messages_today

@app.route('/')
@login_required
def home():
    # Calculate remaining messages
    today = str(date.today())
    if current_user.last_message_date != today:
        remaining = MESSAGES_PER_DAY
    else:
        remaining = MESSAGES_PER_DAY - (current_user.messages_today or 0)

    return render_template('index.html',
                         username=current_user.username,
                         class_of=current_user.class_of,
                         messages_remaining=remaining)

@app.route('/get_history', methods=['GET'])
@login_required
def get_history():
    """Load previous chat messages for this user"""
    try:
        thread_id = current_user.thread_id

        if not thread_id:
            # No previous conversation
            return jsonify({'messages': []})

        # Get all messages from the thread
        messages = client.beta.threads.messages.list(
            thread_id=thread_id,
            order='asc',  # Oldest first
            limit=100  # Get last 100 messages
        )

        # Format messages for display
        chat_history = []
        for msg in messages.data:
            role = msg.role  # 'user' or 'assistant'
            content = msg.content[0].text.value

            # Remove user context from user messages
            if role == 'user' and '[User Context:' in content:
                # Extract just the student question
                parts = content.split('Student Question: ')
                if len(parts) > 1:
                    content = parts[1]

            # Remove citations from assistant messages
            if role == 'assistant':
                content = process_citations(content)

            # Convert markdown to HTML for assistant messages
            if role == 'assistant':
                content = markdown.markdown(
                    content,
                    extensions=['fenced_code', 'codehilite', 'nl2br', 'tables', 'sane_lists']
                )
            else:
                # For user messages, convert newlines to <br>
                content = content.replace('\n', '<br>')

            chat_history.append({
                'role': role,
                'content': content
            })

        return jsonify({'messages': chat_history})

    except Exception as e:
        print(f"Error loading history: {e}")
        return jsonify({'messages': []})

@app.route('/get_remaining_messages', methods=['GET'])
@login_required
def get_remaining_messages():
    """Get remaining messages for current user"""
    today = str(date.today())
    if current_user.last_message_date != today:
        remaining = MESSAGES_PER_DAY
    else:
        remaining = MESSAGES_PER_DAY - (current_user.messages_today or 0)

    return jsonify({'remaining': remaining})

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, password_hash, class_of, thread_id, messages_today, last_message_date FROM users WHERE username = ?', (username,))
        user_data = cursor.fetchone()
        conn.close()

        if user_data and check_password_hash(user_data[2], password):
            user = User(user_data[0], user_data[1], user_data[3], user_data[4], user_data[5] or 0, user_data[6])
            login_user(user)
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error='Invalid username or password')

    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        class_of = request.form.get('class_of')

        if len(username) < 3:
            return render_template('signup.html', error='Username must be at least 3 characters')

        if len(password) < 6:
            return render_template('signup.html', error='Password must be at least 6 characters')

        password_hash = generate_password_hash(password)

        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute('INSERT INTO users (username, password_hash, class_of, messages_today, last_message_date) VALUES (?, ?, ?, 0, ?)',
                         (username, password_hash, class_of, str(date.today())))
            conn.commit()
            conn.close()

            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            return render_template('signup.html', error='Username already exists')

    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/chat', methods=['POST'])
@login_required
def chat():
    data = request.get_json()
    user_message = data.get('message', '')

    print(f"\n[{current_user.username}] sent: {user_message}")

    # Check rate limit
    allowed, count = check_and_update_rate_limit(current_user.id)

    if not allowed:
        return jsonify({
            'response': f'<p><strong>Daily message limit reached!</strong></p><p>You\'ve used all {MESSAGES_PER_DAY} messages for today. Your limit will reset tomorrow.</p><p>If you need more assistance, please contact your school counselor directly.</p>',
            'limit_reached': True
        })

    try:
        # Get or create thread for this user
        thread_id = current_user.thread_id

        if not thread_id:
            thread = client.beta.threads.create()
            thread_id = thread.id

            # Save thread_id to database
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET thread_id = ? WHERE id = ?', (thread_id, current_user.id))
            conn.commit()
            conn.close()

            current_user.thread_id = thread_id
            print(f"Created new thread for {current_user.username}: {thread_id}")

        # Add user context to the message - let AI figure out the grade
        contextual_message = f"""[User Context: Username: {current_user.username}, Graduation Year: Class of {current_user.class_of}]

Student Question: {user_message}"""

        # Add message with context
        client.beta.threads.messages.create(
            thread_id=thread_id,
            role="user",
            content=contextual_message
        )

        # Run assistant
        run = client.beta.threads.runs.create(
            thread_id=thread_id,
            assistant_id=ASSISTANT_ID
        )

        # Wait for completion
        while run.status in ['queued', 'in_progress']:
            time.sleep(0.5)
            run = client.beta.threads.runs.retrieve(
                thread_id=thread_id,
                run_id=run.id
            )

        # Get response
        messages = client.beta.threads.messages.list(
            thread_id=thread_id,
            order='desc',
            limit=1
        )

        bot_response_text = messages.data[0].content[0].text.value
        bot_response_text = process_citations(bot_response_text)

        print(f"Assistant responded: {bot_response_text[:100]}...")

        # Convert markdown to HTML
        bot_response = markdown.markdown(
            bot_response_text,
            extensions=['fenced_code', 'codehilite', 'nl2br', 'tables', 'sane_lists']
        )

        # Add remaining messages info
        remaining = MESSAGES_PER_DAY - count
        if remaining <= 3:
            bot_response += f'<p style="margin-top: 15px; font-size: 12px; opacity: 0.7;"><em>💬 {remaining} messages remaining today</em></p>'

        return jsonify({'response': bot_response})

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'response': 'Sorry, I encountered an error. Please try again.'})

if __name__ == '__main__':
    app.run(debug=False)